This is Minecraft Bedrock client. To launch unpack .zip file and open Muczek Client.bat file.
Client is beta so can cause game crash sometimes but not often.
